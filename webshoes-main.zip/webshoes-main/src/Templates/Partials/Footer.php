<div class="bg-main">
    <div class="container">
        <nav class="navbar bg-head m text-white">
            <div class="col-3">
                <label for="">THẾ GIỚI GIÀY</label>
                <p class="p-footer">
                    Sẵn sàng hợp tác, phục vụ tận tâm, lắng nghe và chia sẻ là điểm mạnh giúp MoonShoes trở nên gần gũi và thân thiện hơn với mọi người.
                    Hãy ghé thăm nơi “chứa đựng thế giới riêng” để tìm kiếm sản phẩm  phù hợp cho riêng mình.
                </p>
            </div>
            <div class="col-3 mb-auto">
                <label>MOONSHOES</label>
                <p class="p-footer"><i class="fas fa-map-marker-alt"></i>
                    Số 34 Việt Bắc, Đồng Quang, Thành phố Thái Nguyên, Thái Nguyên</p>
                <p class="p-footer"><i class="fas fa-comments"></i>
                    24/7 Online Support</p>
                <p class="p-footer"><i class="fas fa-envelope"></i>
                    moonshoes@gmail.com</p>
                <p class="p-footer"><i class="fas fa-phone"></i>
                    0962.296.199</p>
            </div>
            <div class="col-3 mb-auto">
                <label>KẾT NỐI VỚI CHÚNG TÔI</label>
                <div class="m-auto">
                    <img src="Image/square_icon-facebook.png" width="50px">
                    <img src="Image/youtube-512.png" width="50px">
                    <img src="Image/Icon-Zalo-Zalo.jpg" width="50px" alt="">
                    <img src="Image/square-twitter-512.png" width="50px" alt="">
                </div>
            </div>
        </nav>
    </div>
</div>