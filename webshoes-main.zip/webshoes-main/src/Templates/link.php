<!--CSS-->
<link href="bootstrap/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="Css/css.css">
<link rel="stylesheet" href="fontawesome/css/all.css">
<link rel="stylesheet" href="slick/slick-1.8.1/slick/slick.css">
<link rel="stylesheet" href="slick/slick-1.8.1/slick/slick-theme.css">
<link rel="stylesheet" href="bootstrap/jquery.bootstrap-touchspin.css">

<!-- JS-->

<script src="bootstrap/jquery-3.3.1.slim.min.js"></script>
<script src="bootstrap/jquery.min.js"></script>
<script src="bootstrap/bootstrap.min.js"></script>
<script src="bootstrap/bootstrap.bundle.js"></script>
<script src="bootstrap/popper.min.js"></script>
<script src="bootstrap/jquery.bootstrap-touchspin.js"></script>