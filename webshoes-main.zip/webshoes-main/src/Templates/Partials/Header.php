<div id="head" class="mt-1">
    <div class="container">
        <ul class="d-flex bd-highlight justify-content-start main_menu">
            <li><a class="item-menu" href="">Danh Mục Sản Phẩm <i class="fas fa-bars"></i></a>
                <ul class="sub_menu" style="z-index: 99999">
                    <li><a href="index.php?task=pageadidas"><img src="Image/adidas.png" width="15px" alt=""> Giày Adidas</a></li>
                    <li><a href="index.php?task=pagebalance"><img src="Image/balance.png" width="15px" alt=""> Giày Balance</a></li>
                    <li><a href="index.php?task=pagepuma"><img src="Image/puma.png" width="15px" alt=""> Giày Puma</a></li>
                    <li><a href="index.php?task=pageconverse"><img src="Image/converse.png" width="15px" alt=""> Giày Converse</a></li>
                    <li><a href="index.php?task=pagebalenciaga"><img src="Image/balenciaga.png" width="15px" alt=""> Giày Balenciaga</a></li>
                    <li><a href="index.php?task=pagevans"><img src="Image/vans.png" width="15px" alt=""> Giày Vans</a></li>

                </ul>
            </li>
            <li class="px-2 flex-grow-1 bd-highlight" ><a class="item-menu" href="index.php?task=pagehome">Trang Chủ</a></li>
            <li class="px-2 flex-grow-1 bd-highlight"><a class="item-menu" href="index.php?task=pagenews">Tin Tức</a></li>
            <li class="px-2 flex-grow-1 bd-highlight"><a class="item-menu" href="index.php?task=pagemenshoes">Giày Nam</a></li>
            <li class="px-2 flex-grow-1 bd-highlight"><a class="item-menu" href="index.php?task=pagewomenshoes">Giày Nữ</a></li>
            <li class="px-2 flex-grow-1 bd-highlight"><a class="item-menu" href="index.php?task=pagecontact">Liên Hệ</a></li>
        </ul>
    </div>
</div>
